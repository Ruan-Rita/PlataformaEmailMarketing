<tr>
<td class="header">
<img src="<?php echo e(asset('assets/logo-big.png')); ?>" class="logo" alt="Laravel Logo">
<?php echo e($slot); ?>

</a>
</td>
</tr>
<?php /**PATH C:\Users\ruan_\Desktop\teste\Vaga\api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>