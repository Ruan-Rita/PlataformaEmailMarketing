<?php echo e($slot); ?>

<?php /**PATH C:\Users\ruan_\Desktop\teste\Vaga\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>