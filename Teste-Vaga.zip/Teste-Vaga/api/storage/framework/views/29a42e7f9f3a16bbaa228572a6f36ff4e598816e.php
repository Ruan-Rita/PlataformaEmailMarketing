<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ruan_\Desktop\teste\Vaga\api\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>