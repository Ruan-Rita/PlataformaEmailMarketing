import React from "react";

const Footer: React.FC = () => {
  return <>Rusan</>;
};

export default Footer;
