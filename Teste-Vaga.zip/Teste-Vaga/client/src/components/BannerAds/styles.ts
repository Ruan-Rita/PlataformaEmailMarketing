import styled from "styled-components";

export const Container = styled.main`
  width: 100%;
`;
