import React from "react";
import Header from "../../components/Header";
import { Container, Content } from "./styles";
const Templates: React.FC = () => {
  return (
    <Container>
      <Header />

      <Content>templates</Content>
    </Container>
  );
};

export default Templates;
