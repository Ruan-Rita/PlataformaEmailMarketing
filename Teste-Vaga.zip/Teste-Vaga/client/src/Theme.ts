export const Theme = {
  backgroundPrimary: "#9822FF",
  title: "#656466",
  backgroundForm: "#eee",
  submitButton: "#09E22E",
};
