export const config = {
  API: "http://127.0.0.1:8000/api",
  API_TEMPLATE: "http://127.0.0.1:8000",
  APP_MODE: "development",
};
